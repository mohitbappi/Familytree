package pack1;
import java.util.ArrayList;
public class Exam
{
    public ArrayList al2=new ArrayList();
    public static ArrayList exam() throws ClassNotFoundException
    {                       
//        visited[u]=1;
//        for(int i=0;i<al.get(u).size();i++)
//        {
//            al3.add(al.get(u).get(i));            
//        }
//        int a=Integer.getInteger((String) al3.get(0));
//        al2.add(a);
////        if(al3.isEmpty())
////            return al2;
////        else
////            exam(visited,al,a,al3);                
////        al3.remove(0);        
        ArrayList al3=new ArrayList();
        return al3;        
    }
}
