package pack1;
import java.io.*; 
import java.util.*; 
public class Test 
{ 
    private static String s;
    private int V;
    private static LinkedList<Integer> adj[]; 
    public Test(int v) 
    { 
        V = v; 
        adj = new LinkedList[v]; 
        for (int i=0; i<v; ++i) 
            adj[i] = new LinkedList(); 
    } 
    public void addEdge(int v, int w) 
    { 
            adj[v].add(w); // Add w to v's list. 
    }      
    public void DFSUtil(int v,boolean visited[],String arr[]) 
    { 
        visited[v] = true;                 		                       
        s+="'name': "+"'"+arr[(v+1)]+"',\n";	
        Iterator<Integer> i = adj[v].listIterator(); 
        int flag1=0;
        if(i.hasNext())
        {             
            s+="'children':[{\n";
        }
        int flag=1;
        int cnt=0;
        while (i.hasNext()) 
        { 
            if(cnt>=1)
            {         
                s+="},\n{\n";
            }
            flag=0;
            int n = i.next(); 
            if (!visited[n]) 
            {                            
                DFSUtil(n, visited,arr);                        
            } 
            cnt++;
        }                   
        if(flag==0)                  
            s+="}]\n";
    }            	
    public void DFS(int v,String arr[]) 
    {             
        boolean visited[] = new boolean[V];         
        DFSUtil(v, visited,arr); 
    } 
    public static String call(ArrayList<ArrayList<Integer>> al,String arr[])
    {
        s="";
        Test g = new Test(arr.length); 
        for(int a=0;a<al.size();a++)
        {
            for(int b=0;b<al.get(a).size();b++)
            {                
                g.addEdge((a-1),(al.get(a).get(b))-1);
            }
        }       
        g.DFS(0,arr); 
        s=s.replace("null", "");
        System.out.println(s);
        for(int z=0;z<adj.length;z++)
            System.out.println(adj[z]);                
        return s;
    }        
    public static void main(String args[]) 
    { 
    } 
} 

